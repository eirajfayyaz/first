package com.cardgame.fifteenfromthree;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Game {
    private List<Player> players;
    private int numRounds;
    private List<GameRound> rounds;
    
    public Game() {
        players = new ArrayList<>();
        rounds = new ArrayList<>();
    }
    
    public void setup() {
        Scanner scanner = new Scanner(System.in);
        
        // Get number of players
        int numPlayers = 0;
        while (numPlayers < 1 || numPlayers > 6) {
            System.out.print("Enter number of players (1-6): ");
            try {
                numPlayers = Integer.parseInt(scanner.nextLine());
                if (numPlayers < 1 || numPlayers > 6) {
                    System.out.println("Please enter a number between 1 and 6.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
        
        // Get player names
        for (int i = 0; i < numPlayers; i++) {
            System.out.print("Enter name for player " + (i + 1) + " (or 'Computer' for AI): ");
            String name = scanner.nextLine();
            players.add(new Player(name));
        }
        
        // Get number of rounds
        while (numRounds < 1 || numRounds > 5) {
            System.out.print("Enter number of rounds (1-5): ");
            try {
                numRounds = Integer.parseInt(scanner.nextLine());
                if (numRounds < 1 || numRounds > 5) {
                    System.out.println("Please enter a number between 1 and 5.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
    }
    
    public void play() {
        for (int i = 0; i < numRounds; i++) {
            Deck deck = new Deck();
            GameRound round = new GameRound(players, deck, i + 1);
            round.play();
            rounds.add(round);
        }
        
        displayFinalScores();
        announceWinner();
        HighScoreManager.displayHighScores();
    }
    
    private void displayFinalScores() {
        System.out.println("\n=== Final Scores ===");
        for (Player player : players) {
            System.out.println(player.getName() + ": " + player.getTotalScore());
            HighScoreManager.addScore(player.getName(), player.getTotalScore(), numRounds);
        }
    }
    
    private void announceWinner() {
        if (players.isEmpty()) return;
        
        // Sort players by score (ascending - lower is better)
        Collections.sort(players, new Comparator<Player>() {
            @Override
            public int compare(Player p1, Player p2) {
                return Integer.compare(p1.getTotalScore(), p2.getTotalScore());
            }
        });
        
        int winningScore = players.get(0).getTotalScore();
        List<Player> winners = new ArrayList<>();
        
        for (Player player : players) {
            if (player.getTotalScore() == winningScore) {
                winners.add(player);
            }
        }
        
        if (winners.size() == 1) {
            System.out.println("\nThe winner is " + winners.get(0).getName() + " with a score of " + winningScore + "!");
        } else {
            System.out.println("\nIt's a tie between:");
            for (Player winner : winners) {
                System.out.println("- " + winner.getName());
            }
            System.out.println("with a score of " + winningScore + " each!");
        }
    }
    
    public static void main(String[] args) {
        Game game = new Game();
        game.setup();
        game.play();
    }
}