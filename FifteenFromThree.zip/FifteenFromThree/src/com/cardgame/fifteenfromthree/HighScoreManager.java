package com.cardgame.fifteenfromthree;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class HighScoreManager {
    private static final String HIGH_SCORE_FILE = "highscores.txt";
    
    public static void addScore(String playerName, int totalScore, int numRounds) {
        double averageScore = Math.round((totalScore * 100.0 / numRounds)) / 100.0;
        String scoreEntry = averageScore + " " + playerName;
        
        List<String> scores = new ArrayList<>();
        scores.add(scoreEntry);
        
        // Read existing scores
        try (BufferedReader reader = new BufferedReader(new FileReader(HIGH_SCORE_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                scores.add(line);
            }
        } catch (IOException e) {
            // File doesn't exist yet, that's fine
        }
        
        // Sort scores
        Collections.sort(scores, new Comparator<String>() {
            @Override
            public int compare(String s1, String s2) {
                double score1 = Double.parseDouble(s1.split(" ")[0]);
                double score2 = Double.parseDouble(s2.split(" ")[0]);
                return Double.compare(score1, score2);
            }
        });
        
        // Keep only top 5
        if (scores.size() > 5) {
            scores = scores.subList(0, 5);
        }
        
        // Write back to file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(HIGH_SCORE_FILE))) {
            for (String score : scores) {
                writer.write(score);
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving high scores: " + e.getMessage());
        }
    }
    
    public static void displayHighScores() {
        System.out.println("\n=== High Scores ===");
        
        try (BufferedReader reader = new BufferedReader(new FileReader(HIGH_SCORE_FILE))) {
            String line;
            int rank = 1;
            while ((line = reader.readLine()) != null) {
                System.out.println(rank + ". " + line);
                rank++;
            }
            
            if (rank == 1) {
                System.out.println("No high scores yet!");
            }
        } catch (IOException e) {
            System.out.println("No high scores yet!");
        }
    }
}