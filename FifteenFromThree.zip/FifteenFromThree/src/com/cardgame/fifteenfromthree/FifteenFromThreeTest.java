package com.cardgame.fifteenfromthree;

import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;

public class FifteenFromThreeTest {
    
    private Player computer;
    private Player human;
    private Deck deck;
    
    @Before
    public void setUp() {
        computer = new Player("Computer");
        human = new Player("Human");
        deck = new Deck();
    }

    // Test 1: Computer finds perfect 15 combination
    @Test
    public void testComputerFindsOptimal15Combination() {
        List<Card> testHand = List.of(
            new Card("♦", "7"),  // 7
            new Card("♦", "5"),  // 5
            new Card("♦", "3"),  // 3 (7+5+3=15)
            new Card("♣", "K"),  // 10
            new Card("♠", "2")   // 2
        );
        computer.setHand(testHand);
        
        List<Card> bestSubset = computer.findBestSubset();
        
        assertEquals("Should keep exactly 3 cards", 3, bestSubset.size());
        assertEquals("Should total 15", 15, computer.calculateHandValue(bestSubset));
        assertContainsAll(bestSubset, List.of("7♦", "5♦", "3♦"));
    }

    // Test 2: Computer handles no-perfect-15 scenario
    @Test
    public void testComputerChoosesClosestWhenNo15Exists() {
        List<Card> testHand = List.of(
            new Card("♥", "2"),
            new Card("♠", "3"),
            new Card("♦", "4"),
            new Card("♣", "Q"),  // 10
            new Card("♥", "5")    // 2+3+10=15 would need 3 cards
        );
        computer.setHand(testHand);
        
        List<Card> bestSubset = computer.findBestSubset();
        int sum = computer.calculateHandValue(bestSubset);
        
        assertTrue("Sum should be close to 15", Math.abs(15 - sum) <= 3);
    }

    // Test 3: Ace value calculation
    @Test
    public void testAceValueCalculation() {
        List<Card> testHand = List.of(
            new Card("♦", "A"),  // 11 or 1
            new Card("♥", "4"),  // 4
            new Card("♠", "K")   // 10
        );
        human.setHand(testHand);
        
        assertEquals("Should use Ace=1 to make 15 (1+4+10)", 
            15, human.calculateHandValue(testHand));
    }

    // Test 4: Score calculation with bonuses
    @Test
    public void testScoreCalculationWithBonuses() {
        List<Card> perfectHand = List.of(
            new Card("♦", "7"),
            new Card("♦", "5"),
            new Card("♦", "3")  // All diamonds, total 15
        );
        human.setHand(perfectHand);
        
        assertEquals("Should get -3 bonus (15 + same color + same suit)",
            -3, human.calculateScore());
    }

    // Test 5: All Aces handling
    @Test
    public void testAllAcesHandling() {
        List<Card> allAces = List.of(
            new Card("♦", "A"),
            new Card("♠", "A"),
            new Card("♥", "A")
        );
        computer.setHand(allAces);
        
        List<Card> best = computer.findBestSubset();
        assertEquals("Three aces should total 13 (1+1+11)", 
            13, computer.calculateHandValue(best));
    }
    // Test 6: Deck dealing functionality
    @Test
    public void testDeckDealsCorrectNumberOfCards() {
        List<Card> cards = deck.deal(5);
        assertEquals("Should deal exactly 5 cards",
            5, cards.size());
    }

    // Test 7: Edge case - all face cards
    @Test
    public void testAllFaceCardsHand() {
        List<Card> faceCards = List.of(
            new Card("♦", "J"),
            new Card("♠", "Q"),
            new Card("♥", "K"),
            new Card("♣", "J"),
            new Card("♦", "Q")
        );
        computer.setHand(faceCards);
        
        List<Card> best = computer.findBestSubset();
        assertEquals("Best possible should be 30 (10+10+10)",
            30, computer.calculateHandValue(best));
    }

    // Helper method for card assertions
    private void assertContainsAll(List<Card> actualCards, List<String> expected) {
        for (String expectedCard : expected) {
            boolean found = actualCards.stream()
                .anyMatch(c -> c.toString().equals(expectedCard));
            assertTrue("Missing card: " + expectedCard, found);
        }
    }
}