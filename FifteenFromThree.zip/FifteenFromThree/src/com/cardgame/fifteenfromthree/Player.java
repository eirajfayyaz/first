package com.cardgame.fifteenfromthree;

import java.util.ArrayList;
import java.util.List;

public class Player {
    private String name;
    private List<Card> hand;
    private int totalScore;
    private boolean isComputer;
    
    public Player(String name) {
        this.name = name;
        this.hand = new ArrayList<>();
        this.totalScore = 0;
        this.isComputer = name.equalsIgnoreCase("Computer");
    }
    
    public void dealHand(Deck deck) {
        hand = deck.deal(5);
    }
    
    public void setHand(List<Card> hand) {
        this.hand = new ArrayList<>(hand);
    }
    
    public int calculateHandValue(List<Card> cards) {
        if (cards == null || cards.isEmpty()) {
            return 0;
        }
        
        boolean hasAce = cards.stream().anyMatch(c -> c.getRank().equals("A"));
        if (!hasAce) {
            return cards.stream().mapToInt(c -> c.getValue()).sum();
        } else {
            return calculateBestAceValue(cards);
        }
    }
    
    private int calculateBestAceValue(List<Card> cards) {
        List<Card> aces = new ArrayList<>();
        List<Card> nonAceCards = new ArrayList<>();
        
        for (Card card : cards) {
            if (card.getRank().equals("A")) {
                aces.add(card);
            } else {
                nonAceCards.add(card);
            }
        }
        
        int baseSum = nonAceCards.stream().mapToInt(c -> c.getValue()).sum();
        int bestSum = 0;
        int bestDiff = Integer.MAX_VALUE;
        int numAces = aces.size();
        
        for (int i = 0; i < (1 << numAces); i++) {
            int currentSum = baseSum;
            for (int j = 0; j < numAces; j++) {
                if ((i >> j & 1) == 1) {
                    currentSum += 11;
                } else {
                    currentSum += 1;
                }
            }
            
            int currentDiff = Math.abs(currentSum - 15);
            if (currentDiff < bestDiff || (currentDiff == bestDiff && currentSum < bestSum)) {
                bestDiff = currentDiff;
                bestSum = currentSum;
            }
        }
        
        return bestSum;
    }
    
    public List<Card> findBestSubset() {
        List<Card> bestSubset = null;
        int bestDiff = Integer.MAX_VALUE;
        int bestSum = 0;
        
        for (int i = 0; i < hand.size(); i++) {
            for (int j = i + 1; j < hand.size(); j++) {
                for (int k = j + 1; k < hand.size(); k++) {
                    List<Card> subset = new ArrayList<>();
                    subset.add(hand.get(i));
                    subset.add(hand.get(j));
                    subset.add(hand.get(k));
                    
                    int sum = calculateHandValue(subset);
                    int diff = Math.abs(sum - 15);
                    
                    if (diff < bestDiff || (diff == bestDiff && sum < bestSum)) {
                        bestDiff = diff;
                        bestSum = sum;
                        bestSubset = subset;
                    }
                }
            }
        }
        
        return bestSubset;
    }
    
    // Other existing methods...
    public void displayHand() {
        System.out.println("\n" + name + "'s hand:");
        for (int i = 0; i < hand.size(); i++) {
            System.out.println((i + 1) + ": " + hand.get(i));
        }
    }
    
    public void removeCards(List<Integer> indicesToRemove, Deck deck) {
        indicesToRemove.sort((a, b) -> b - a);
        for (int index : indicesToRemove) {
            if (index >= 0 && index < hand.size()) {
                hand.remove(index);
            }
        }
        while (hand.size() < 3 && !deck.deal(1).isEmpty()) {
            hand.addAll(deck.deal(1));
        }
    }
    
    public int calculateScore() {
        if (hand.size() != 3) return 0;
        
        int handValue = calculateHandValue(hand);
        int score = Math.abs(handValue - 15);
        
        boolean allSameColor = hand.stream()
            .map(c -> c.getColor())
            .distinct()
            .count() == 1;
        if (allSameColor) score -= 1;
        
        boolean allSameSuit = hand.stream()
            .map(c -> c.getSuit())
            .distinct()
            .count() == 1;
        if (allSameSuit) score -= 2;
        
        return score;
    }
    
    // Getters
    public String getName() { return name; }
    public List<Card> getHand() { return hand; }
    public int getTotalScore() { return totalScore; }
    public boolean isComputer() { return isComputer; }
    
    // Setter
    public void addToTotalScore(int score) { totalScore += score; }
}