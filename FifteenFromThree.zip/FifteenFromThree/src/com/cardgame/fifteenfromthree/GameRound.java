package com.cardgame.fifteenfromthree;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GameRound {
    private List<Player> players;
    private Deck deck;
    private int roundNumber;
    
    public GameRound(List<Player> players, Deck deck, int roundNumber) {
        this.players = players;
        this.deck = deck;
        this.roundNumber = roundNumber;
    }
    
    public void play() {
        System.out.println("\n=== Round " + roundNumber + " ===");
        
        for (Player player : players) {
            player.dealHand(deck);
            player.displayHand();
            
            if (player.isComputer()) {
                playComputerTurn(player);
            } else {
                playHumanTurn(player);
            }
            
            int score = player.calculateScore();
            player.addToTotalScore(score);
            
            System.out.println(player.getName() + "'s score for this round: " + score);
            System.out.println("Current hand: " + player.getHand());
        }
    }
    
    private void playComputerTurn(Player player) {
        System.out.println("\nComputer is thinking...");
        
        List<Card> bestSubset = player.findBestSubset();
        List<Integer> indicesToRemove = new ArrayList<>();
        
        // Find indices of cards not in the best subset
        for (int i = 0; i < player.getHand().size(); i++) {
            if (!bestSubset.contains(player.getHand().get(i))) {
                indicesToRemove.add(i);
            }
        }
        
        System.out.println("Computer removes cards at positions: " + 
            indicesToRemove.stream().map(i -> i + 1).toList());
        
        player.removeCards(indicesToRemove, deck);
    }
    
    private void playHumanTurn(Player player) {
        Scanner scanner = new Scanner(System.in);
        List<Integer> indicesToRemove = new ArrayList<>();
        
        while (indicesToRemove.size() < 2) {
            System.out.print("Enter card numbers to remove (at least 2, space separated): ");
            String input = scanner.nextLine();
            
            try {
                String[] parts = input.split(" ");
                for (String part : parts) {
                    int index = Integer.parseInt(part) - 1;
                    if (index >= 0 && index < player.getHand().size()) {
                        indicesToRemove.add(index);
                    }
                }
                
                if (indicesToRemove.size() < 2) {
                    System.out.println("You must remove at least 2 cards. Try again.");
                    indicesToRemove.clear();
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter numbers only.");
                indicesToRemove.clear();
            }
        }
        
        player.removeCards(indicesToRemove, deck);
    }
}