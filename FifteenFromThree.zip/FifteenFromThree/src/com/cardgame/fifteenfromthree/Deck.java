package com.cardgame.fifteenfromthree;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Deck {
    private List<Card> cards;
    private static final String[] SUITS = {"♦", "♣", "♥", "♠"};
    private static final String[] RANKS = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
    
    public Deck() {
        cards = new ArrayList<>();
        initializeDeck();
        shuffle();
    }
    
    private void initializeDeck() {
        for (String suit : SUITS) {
            for (String rank : RANKS) {
                cards.add(new Card(suit, rank));
            }
        }
    }
    
    public void shuffle() {
        Collections.shuffle(cards);
    }
    
    public List<Card> deal(int numCards) {
        List<Card> dealtCards = new ArrayList<>();
        for (int i = 0; i < numCards; i++) {
            if (cards.isEmpty()) break;
            dealtCards.add(cards.remove(0));
        }
        return dealtCards;
    }
    
    public int remainingCards() {
        return cards.size();
    }
}