package com.cardgame.fifteenfromthree;

import java.util.Objects;

public class Card {
    private String suit;
    private String rank;
    
    public Card(String suit, String rank) {
        this.suit = suit;
        this.rank = rank;
    }
    
    public String getSuit() {
        return suit;
    }
    
    public String getRank() {
        return rank;
    }
    
    public Integer getValue() {
        if (rank.equals("J") || rank.equals("Q") || rank.equals("K")) {
            return 10;
        } else if (rank.equals("A")) {
            return null; // Special handling needed for Ace
        } else {
            return Integer.parseInt(rank);
        }
    }
    
    public String getColor() {
        return suit.equals("♦") || suit.equals("♥") ? "red" : "black";
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Card card = (Card) obj;
        return suit.equals(card.suit) && rank.equals(card.rank);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(suit, rank);
    }
    
    @Override
    public String toString() {
        return rank + suit;
    }
}